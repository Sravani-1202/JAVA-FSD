package practiceproject3;

 import java.util.Scanner;

public class SumRange {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Input the number of elements in the array
        System.out.print("Enter the number of elements (n): ");
        int n = scanner.nextInt();
        
        // Create an array to store the elements
        int[] arr = new int[n];
        
        // Input the elements
        System.out.println("Enter the elements:");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }
        
        // Input the range [L, R]
        System.out.print("Enter the left index (L): ");
        int L = scanner.nextInt();
        System.out.print("Enter the right index (R): ");
        int R = scanner.nextInt();
        
        // Check for valid range
        if (L < 0 || R >= n || L > R) {
            System.out.println("Invalid range.");
            return;
        }
        
        // Calculate the sum of elements in the range [L, R]
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += arr[i];
        }
        
        // Display the sum
        System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sum);
    }
}


