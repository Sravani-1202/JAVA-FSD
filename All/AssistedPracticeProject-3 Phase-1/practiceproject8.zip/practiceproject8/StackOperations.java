package practiceproject8;
import java.util.Stack;

public class StackOperations {
	 public static void main(String[] args) {
	        // Create a stack
	        Stack<Integer> stack = new Stack<>();

	        // Push elements onto the stack
	        stack.push(19);
	        stack.push(45);
	        stack.push(24);

	        System.out.println("Stack: " + stack);

	        // Pop an element from the stack
	        int poppedElement = stack.pop();
	        System.out.println("Popped Element: " + poppedElement);

	        System.out.println("Stack after popping: " + stack);
	    }
	}


