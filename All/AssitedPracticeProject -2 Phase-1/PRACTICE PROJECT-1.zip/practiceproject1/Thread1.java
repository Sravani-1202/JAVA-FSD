package practiceproject1;


	public class Thread1 {//creating a thread class
		void run() {
			System.out.println("Thread 1 is created");
			System.out.println("Thread 2 is created");
		}
		}


