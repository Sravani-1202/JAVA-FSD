package practiceproject1;



public class Thread2 extends Thread1{//extending the thread class

	public static void main(String[] args) { 
		Thread1 th1=new Thread1();//creating an object for thread class
		th1.run();
		System.out.println("Threads are created sucessfully");// TODO Auto-generated method stub
	}
}


