package practiceproject1;



public class Thread3 implements Runnable{//creating a thread using runnable interface
	 public void run() {
		System.out.println("Thread is created");
	}
	public static void main(String[] args) {
		Thread3 th2=new Thread3();
		th2.run();
	}

}
