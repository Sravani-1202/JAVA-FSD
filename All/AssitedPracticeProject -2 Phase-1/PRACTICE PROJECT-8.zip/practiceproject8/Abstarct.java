package practiceproject8;

abstract class Abstarct {
	 private String name;
	 
	    public Abstarct(String name) { this.name = name; }
	 
	    public abstract void makeSound();
	 
	    public String getName() 
	    {return name;
	    }
}
