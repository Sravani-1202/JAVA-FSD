package practiceproject8;



public class Cat extends Abstarct{
	public Cat(String name) { super(name); }
	 
    public void makeSound()
    {
        System.out.println(getName() + " meows");
    }
}


