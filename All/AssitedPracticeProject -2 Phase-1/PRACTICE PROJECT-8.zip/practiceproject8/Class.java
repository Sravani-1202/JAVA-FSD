package practiceproject8;


public class Class {
	// Instance Variables
    String name;
    int rollnum;
    int age;
   
    // Constructor Declaration of Class
     Class(String name, int rollnum,int age)
    {
        this.name = name;
        this.rollnum= rollnum;
        this.age = age;
    }
   
    
    public String getName()
    {
        return name;
        
    }
    public int getrollnum()
    {
        return rollnum;
        
    }
    public int getage()
    {
        return age;
        
    }
   
  
    public static void main(String[] args)
    {
        // creating object using new operator
    	Class s1 = new Class("somu",13,23);
        
        System.out.println("StudentName:"+s1.getName());
        System.out.println("StudentRollNumber:"+s1.getrollnum());
        System.out.println("StudentAge:"+s1.getage());
    }


}



