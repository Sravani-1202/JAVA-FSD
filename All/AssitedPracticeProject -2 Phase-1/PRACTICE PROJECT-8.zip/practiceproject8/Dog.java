package practiceproject8;




public class Dog extends Abstarct {
    public Dog(String name) { super(name); }
	 
    public void makeSound()
    {
        System.out.println(getName() + " barks");
    }
    
    	
	    // Main Function
	    public static void main(String[] args)
	    {
	    	Abstarct myDog = new Dog("Buddy");
	    	Cat myCat = new Cat("Fluffy");
	 
	        myDog.makeSound();
	        myCat.makeSound();
	    }
	}

