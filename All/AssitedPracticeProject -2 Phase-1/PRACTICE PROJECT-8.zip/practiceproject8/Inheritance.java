package practiceproject8;

public class Inheritance {
	void display() {
		System.out.println("Dispaly Method Excecuted");
	}

}
