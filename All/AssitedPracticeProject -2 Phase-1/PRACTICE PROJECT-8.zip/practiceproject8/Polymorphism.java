package practiceproject8;



public class Polymorphism {
	public int sub(int x, int y) 
    { 
        return (x*y); 
    } 
    public int sub(int x, int y, int z) 
    { 
        return (x* y - z); 
    } 
    public double sub(double x, double y) 
    { 
        return (x + y); 
    } 
    public static void main(String args[]) 
    { 
    	Polymorphism s = new Polymorphism(); 
        System.out.println(s.sub(5, 10)); 
        System.out.println(s.sub(5, 10, 30)); 
        System.out.println(s.sub(5.5, 10.5)); 
    } 
}



