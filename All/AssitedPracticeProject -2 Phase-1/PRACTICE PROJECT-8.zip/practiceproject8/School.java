package practiceproject8;



public class School extends Inheritance{
	

	  private String name;

	public void getInfo() {
	    System.out.println("My name is " + name);
	  }

	

public static void main(String[] args) {
	
  // create an object of the subclass
 School cv=new School();

  // access protected field and method
  // using the object of subclass
 cv.name = "jhon";
 cv.display();

 cv.getInfo();
}


}
