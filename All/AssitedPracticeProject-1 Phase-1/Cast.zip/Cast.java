package project;

public class Cast {

	public static void main(String[] args) {
		char c='F';
		int v=c;
		System.out.println("after implicit type casting the value is:"+v);
		int v1='C';
		char C=(char)v1;
		System.out.println("after explicit type casting the value is:"+C);
	}
// TODO Auto-generated method stub

	}


