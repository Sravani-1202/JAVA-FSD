package project;
import java.util.Scanner;

public class ArithmaticCalculator {

	public static void main(String[] args) {
		Scanner Sc= new Scanner(System.in);
		System.out.println("Welcome to Arthimatic Calculator ");
		System.out.println("Enter the first number");
		double num1=Sc.nextDouble();
		System.out.println("Enter the second number");
		double num2= Sc.nextDouble();
		System.out.println("Select an operator");
		System.out.println("1.Addition");
		System.out.println("2.Subtraction");
		System.out.println("3.Multiplication");
		System.out.println("4.Division");
		System.out.println("Enter your choice (1/2/3/4");
		int choice=Sc.nextInt();
		double result=0;
		switch (choice) {
		case 1:
			result= num1+num2;
			break;
		case 2:
			result=num1-num2;
			break;
		case 3:
			result=num1*num2;
			break;
		case 4:
			if(num2 !=0) {
			result=num1/num2;
			}
			else
			{ 
			
				System.out.println("Error:Divisionby zero!");
				System.exit(1);//exit the program
			}
			break;
			default:
				
			System.out.println("Invalid choice!");
			System.exit(1);//exit the program
		
		}
		System.out.println("Result:"+result);
	}
}
		
			
		
		

