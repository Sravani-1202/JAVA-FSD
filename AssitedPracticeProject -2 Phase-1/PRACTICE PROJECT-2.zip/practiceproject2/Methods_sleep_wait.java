package practiceproject2;

public class Methods_sleep_wait {
	private static Object mick = new Object();

	public static void main(String[] args)throws InterruptedException {
		Thread.sleep(1000);
        System.out.println("Thread '" + Thread.currentThread().getName() + "' is woken after sleeping for 1 second");
        synchronized (mick) 
        {
            mick.wait(1000);
            System.out.println("Object '" + mick + "' is woken after" + " waiting for 1 second");
		
		// TODO Auto-generated method stub

	}

}
}


