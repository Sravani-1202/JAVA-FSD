package practiceproject4;

public class Try_catch {
	public static void main(String[] args) {
		int x=20;
		int y=0;
		try{
			int z=x/y;//exception occurs
			System.out.println("the answer is:"+z);
			
		}
		catch(Exception e){//handling the exception by using catch block
			System.out.println(e);
		}
		System.out.println("cannot divide by zero");
		}

	}





