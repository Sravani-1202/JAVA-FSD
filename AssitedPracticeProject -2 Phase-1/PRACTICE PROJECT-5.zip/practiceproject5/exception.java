package practiceproject5;

public class exception {

}
