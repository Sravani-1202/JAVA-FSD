package practiceproject7;
import java.io.*;
import java.util.Scanner;

public class FileOpeartions {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Choose an operation:");
            System.out.println("1. Create File");
            System.out.println("2. Read File");
            System.out.println("3. Update File");
            System.out.println("4. Delete File");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    createFile();
                    break;
                case 2:
                    readFile();
                    break;
                case 3:
                    updateFile();
                    break;
                case 4:
                    deleteFile();
                    break;
                case 5:
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }

    private static void createFile() {
        try {
            System.out.print("Enter the file name: ");
            String fileName = new Scanner(System.in).nextLine();
            System.out.print("Enter the content to write: ");
            String content = new Scanner(System.in).nextLine();

            FileWriter writer = new FileWriter(fileName);
            writer.write(content);
            writer.close();

            System.out.println("File created successfully!");
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void readFile() {
        try {
            System.out.print("Enter the file name to read: ");
            String fileName = new Scanner(System.in).nextLine();

            FileReader reader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(reader);

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line);
            }

            reader.close();
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void updateFile() {
        try {
            System.out.print("Enter the file name to update: ");
            String fileName = new Scanner(System.in).nextLine();
            System.out.print("Enter the new content: ");
            String newContent = new Scanner(System.in).nextLine();

            FileWriter writer = new FileWriter(fileName);
            writer.write(newContent);
            writer.close();

            System.out.println("File updated successfully!");
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void deleteFile() {
        System.out.print("Enter the file name to delete: ");
        String fileName = new Scanner(System.in).nextLine();

        File file = new File(fileName);
        if (file.delete()) {
            System.out.println("File deleted successfully!");
        } else {
            System.out.println("Failed to delete the file.");
        }
    }
}

