package project;
//Parameterized constructor

public class StdId {
	int id;
	String name;

	StdId(int i,String n)
	{
	id=i;
	name=n;
	}

	void display() {
	System.out.println(id+" "+name);
	}

public static void main(String[] args) {

			StdId std1=new StdId(2,"Alex");
			StdId std2=new StdId(10,"Annie");
			std1.display();
			std2.display();
				}
		// TODO Auto-generated constructor stub
	}


