package com.ecommerce;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.apache.catalina.startup.ClassLoaderFactory.Repository;
import org.apache.catalina.startup.ClassLoaderFactory.RepositoryType;

@Configuration
public class CustomConfiguration {
    @Bean
    public Repository classLoaderRepository(String arg1, RepositoryType arg2) {
        // Provide a proper instantiation of Repository here, including any required arguments.
        // For example:
        return new Repository(arg1, arg2); // Replace arg1 and arg2 with actual values
    }
}