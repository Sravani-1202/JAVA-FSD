package com.project.Authentication;

public @interface SpringBootApplication {

}
