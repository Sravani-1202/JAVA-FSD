package project;
import java.util.Scanner;

public class EmailValid {

	public static void main(String[] args) {
		  // Define an array of email IDs
        String[] emailArray = {
            "sravani@noora.com",
            "sweet@home.com",
            "ricky@gamil.com",
            "somu@hotmail.com",
            "lunch@company.com"
        };

        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Ask the user to enter an email ID to search for
        System.out.print("Enter an email ID to search: ");
        String searchEmail = scanner.nextLine();

        // Method 1: Using a for-each loop
        boolean foundMethod1 = false;
        for (String email : emailArray) {
            if (email.equalsIgnoreCase(searchEmail)) {
                foundMethod1 = true;
                break;
            }
        }

        // Method 2: Using the Arrays.binarySearch method (requires sorting)
        // Note: This method requires the array to be sorted, which is not the case here
        // We'll skip this method for unsorted data.

        // Method 3: Using a linear search with a loop
        boolean foundMethod3 = false;
        for (int i = 0; i < emailArray.length; i++) {
            if (emailArray[i].equalsIgnoreCase(searchEmail)) {
                foundMethod3 = true;
                break;
            }
        }

        // Method 4: Using the Arrays.asList and contains methods
        boolean foundMethod4 = java.util.Arrays.asList(emailArray).contains(searchEmail);

        // Check and display the results
        if (foundMethod1 || foundMethod3 || foundMethod4) {
            System.out.println("Email ID found in the array.");
        } else {
            System.out.println("Email ID not found in the array.");
        }

        // Close the Scanner
        scanner.close();
    }
}
		