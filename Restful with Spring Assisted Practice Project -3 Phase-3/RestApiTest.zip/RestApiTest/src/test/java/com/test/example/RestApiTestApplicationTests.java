package com.test.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest

	public class RestApiTestApplicationTests {

	    public static void main(String[] args) {
	        SpringApplication.run(RestApiTestApplicationTests.class, args);
	    }
}
