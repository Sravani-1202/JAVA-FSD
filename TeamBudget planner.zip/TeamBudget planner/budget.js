var budget = null;
        var deals = [];

        function addDeal() {
            var vendor = document.getElementById("vendor").value;
            var deal = document.getElementById("deal").value;
            var expense = parseInt(document.getElementById("expense").value);

            if (vendor == "" || deal == "" || isNaN(expense)) {
                alert("Please fill all fields with valid data.");
                return;
            }

            deals.push({
                vendor: vendor,
                deal: deal,
                expense: expense
            });

            var dealTable = document.getElementById("dealTable");
            var row = dealTable.insertRow();
            var vendorCell = row.insertCell(0);
            var dealCell = row.insertCell(1);
            var expenseCell = row.insertCell(2);
            vendorCell.innerHTML = vendor;
            dealCell.innerHTML = deal;
            expenseCell.innerHTML = expense;

            budget = budget+expense;
            document.getElementById("budget").innerHTML = budget.toLocaleString();

            if (budget < 0) {
                document.getElementById("budgetAlert").classList.remove("alert-success");
                document.getElementById("budgetAlert").classList.add("alert-danger");
            }
        }