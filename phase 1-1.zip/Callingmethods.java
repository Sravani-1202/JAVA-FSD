package project;

public class Callingmethods {
	public int addnumber(int a,int b) {
		int c=a+b;
		return(c);
	}
	 int cal=920;
	 int operation(int cal) {
		 cal=cal*10/100;
		 return(cal);
	 }
	 void add(int g,int h) {
		int i=g+h;
		System.out.println("after addition the value is:" +(g+h));
		}
		void add(int d,int e,int f) {
			int k=d+e+f;
			System.out.println("after addition the value is:"+k);
		}
		 
	 
	
	public static void main(String[] args) {
		Callingmethods obj= new Callingmethods();
		int ans=obj.addnumber(3, 5);
		System.out.println("addition is :"+ans);
		System.out.println("Before operation value of data is "+obj.cal);
		obj.operation(100);//call by value
		System.out.println("After operation value of data is "+obj.cal);
		obj.add(23, 20);//method overloading
		obj.add(56, 74, 78);//method overloading
		

		
		}

	}

		// TODO Auto-generated method stub

	


