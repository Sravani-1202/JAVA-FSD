package project;

public class Main {

	public static void main(String[] args) {
		Acess_modifier am= new Acess_modifier();
	     am.publicMethod();
	     System.out.println(am.publicField);

	     Subclass subclass = new Subclass();
	     subclass.accessFieldsAndMethods(null);
	 }

	}


