package project;
import java.util.*;

public class Maps {

	public static void main(String[] args) {
		//Hashmap
				HashMap<Integer,String> hm=new HashMap<Integer,String>();// creating a hash map    
			      hm.put(1,"Tim");  //entering values into a hash map  
			      hm.put(2,"Mary");    
			      hm.put(3,"Catie");   
			       
			      System.out.println("\nThe elements of Hashmap are ");  
			      for(Map.Entry m:hm.entrySet()){    
			       System.out.println(m.getKey()+" "+m.getValue()); }//printing the elements of hash map
			       System.out.println("size of the hash map is:"+hm.size());//printing the size of the hash map
			       
			      
			      
			     //HashTable
			       
			      Hashtable<Integer,String> ht=new Hashtable<Integer,String>(); //creating a hash table  
			      
			      ht.put(4,"Ales");  //entering values into the hash table
			      ht.put(5,"Rosy");  
			      ht.put(6,"Jack");  
			      ht.put(7,"John");  

			      System.out.println("\nThe elements of HashTable are ");  
			      for(Map.Entry n:ht.entrySet()){    
			       System.out.println(n.getKey()+" "+n.getValue());}// printing the elements of hash table 
			      ht.remove(6,"jack");//removing element in a hash table
			      
			      
			      
			      //TreeMap
			      
			      TreeMap<Integer,String> map=new TreeMap<Integer,String>(); //creating a tree map   
			      map.put(8,"Annie");  //inserting values in tree map  
			      map.put(9,"Carlotte");    
			      map.put(10,"Catie");       
			      
			      System.out.println("\nThe elements of TreeMap are ");  
			      for(Map.Entry l:map.entrySet()){    
			       System.out.println(l.getKey()+" "+l.getValue()); //getting the values of tree map
			       String value9=map.get(9); //printing one value of tree map
			       System.out.println("the value of 9 is"+(value9));
			      }
	}
}
			         
			      
			     
		



// TODO Auto-generated method stub

	


