package project;

public class OuterClass {
	private String outerVariable = "sravani";

    // Inner class
    public class InnerClass {
        public void displayInner() {
            System.out.println("Inner class method called");
            System.out.println("Outer variable from inner class: " + outerVariable);
        }
    }

	public static void main(String[] args) {
OuterClass outerObj = new OuterClass();//creating an instance for outer class
        
        // Creating an instance of the inner class
        OuterClass.InnerClass innerObj = outerObj.new InnerClass();

        innerObj.displayInner();//calling the inner class by using inner class object
    }

		// TODO Auto-generated method stub

	}


